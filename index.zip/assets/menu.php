<div id="navbar" class="navbar-collapse collapse">
    <div class="nav_right_top">
        <div class="menu-first-part">
        <div class="hdr-w3left navbar-left">
				<p><span class="fa fa-mobile"></span> +040 354 658 252 </p> 
			</div>
			<div class="w3ls-bnr-icons social-w3licon navbar-right">
				<a href="#" class="social-button twitter"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
				<a href="#" class="social-button facebook"><i class="fab fa-twitter" aria-hidden="true"></i></a> 
				<a href="#" class="social-button google"><i class="fab fa-instagram" aria-hidden="true"></i></i></a>
			</div>	
        </div>
         <ul class="nav navbar-nav">
            <li class="active">
                <a href="index.php">Home</a>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">About Us
                    <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                    <li>
                        <a class="scroll" href="about-us.php">Vision & Mission</a>
                    </li>
                    <li>
                        <a class="scroll" href="objective.php">Aims & Objective</a>
                    </li>
                    <li>
                        <a class="scroll" href="goal.php">Achievment & Award</a>
                    </li>
                    <li>
                        <a class="scroll" href="methodology.php">Our Team</a>
                    </li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Programme
                    <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                    <li>
                        <a class="scroll" href="about-us.php">Sankalp Chaupal</a>
                    </li>
                    <li>
                        <a class="scroll" href="about-us.php">Jeevan Rekha</a>
                    </li>
                </ul>
            </li>
            <li>
                <a class="scroll" href="vision.php">Legal Status</a>
            </li>   
            <li>
                <a class="scroll" href="mission.php">Gallery</a>
            </li>
            <li>
                <a class="scroll" href="mission.php">Blog</a>
            </li>
            <li>
                <a class="scroll" href="contact.php">Donate Now</a>
            </li>
            <li>
                <a class="scroll" href="governing-body.php">Contact Us</a>
            </li>
        </ul>
    </div>
</div>
