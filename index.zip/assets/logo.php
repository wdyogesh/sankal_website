<div class="navbar-header">
    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false"
        aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
    </button>
    </div>
    <div class="logo_wthree_agile">
        <a class="navbar-brand" href="index.php">
            <div class="log-div">
                <img class="responsive logo-images" src="images/logo3.png" alt="" srcset="">
            </div>
        </a>
    </div>
</div>